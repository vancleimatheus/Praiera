'use strict';
app.controller('FirstStepController', ['$scope', '$location',
    function ($scope, mainService, $location) {
    }
]);