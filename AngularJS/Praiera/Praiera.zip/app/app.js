var app = angular.module('Praiera', ['ngRoute']);

app.config(function ($routeProvider) {    
    $routeProvider.otherwise({ redirectTo: "/firststep" });
});

app.config(function ($routeProvider) {    

    $routeProvider.when("/firststep", {
        controller: "HomeController",
        templateUrl: "/app/views/FirstStep.html"
    });

    $routeProvider.otherwise({ redirectTo: "/firststep" });
});